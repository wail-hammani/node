var loader = require('./dist');

module.exports = loader;