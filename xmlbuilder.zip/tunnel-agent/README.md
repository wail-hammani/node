tunnel-agent
============

HTTP proxy tunneling agent. Formerly part of mikeal/request, now a standalone module.
