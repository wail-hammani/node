export const EMPTY_VALUE = Symbol('EMPTY_VALUE');
//# sourceMappingURL=empty.const.js.map