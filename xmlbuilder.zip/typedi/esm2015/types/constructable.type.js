export {};
//# sourceMappingURL=constructable.type.js.map