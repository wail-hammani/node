export {};
//# sourceMappingURL=abstract-constructable.type.js.map