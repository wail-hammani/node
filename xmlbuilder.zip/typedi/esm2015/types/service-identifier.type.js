export {};
//# sourceMappingURL=service-identifier.type.js.map