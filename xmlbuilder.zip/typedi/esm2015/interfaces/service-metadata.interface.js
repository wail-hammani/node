export {};
//# sourceMappingURL=service-metadata.interface.js.map