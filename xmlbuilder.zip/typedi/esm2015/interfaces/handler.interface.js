export {};
//# sourceMappingURL=handler.interface.js.map