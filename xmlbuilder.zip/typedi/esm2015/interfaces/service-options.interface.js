export {};
//# sourceMappingURL=service-options.interface.js.map