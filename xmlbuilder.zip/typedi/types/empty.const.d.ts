export declare const EMPTY_VALUE: unique symbol;
