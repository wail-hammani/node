# Tedious Benchmarks

This folder contains a collection of benchmarks for `tedious`.

Running an existing benchmark is easy, simply execute the benchmark file with `node`:

```sh
node benchmarks/query/select-many-rows.js
```

**NOTE:** The benchmarks try to load `tedious` code from `lib`, so make sure
you run `npm run prepublish` first.
