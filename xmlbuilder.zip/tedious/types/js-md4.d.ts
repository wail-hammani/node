declare module 'js-md4' {
  declare const md4: {
    arrayBuffer(message: string | ArrayBuffer): ArrayBuffer;
  };

  export = md4;
}
