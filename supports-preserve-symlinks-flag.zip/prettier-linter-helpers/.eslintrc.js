module.exports = {
  plugins: ['node'],
  extends: ['plugin:node/recommended', 'plugin:prettier/recommended'],
  env: {mocha: true},
  root: true,
};
