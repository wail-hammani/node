export declare function exportMetadataPackage(output?: string, manifest?: string): Promise<string>;
