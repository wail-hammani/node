import * as commander from "commander";
export declare function info(manifestPath: string): Promise<void>;
export declare function modify(manifestPath: string, command: commander.Command): Promise<void>;
export declare function validate(manifestPath: string, command: commander.Command): Promise<void>;
export declare function exportManifest(command: commander.Command): Promise<void>;
