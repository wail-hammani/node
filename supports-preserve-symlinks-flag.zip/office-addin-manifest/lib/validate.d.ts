export declare class ManifestValidationDetails {
    adminInstallOnly?: boolean;
    capabilities?: object;
    defaultLocale?: string;
    description?: string;
    displayName?: string;
    hosts?: string[];
    iconUrl?: string;
    localizedDescriptions?: object;
    localizedIconUrls?: object;
    localizedRootSourceUrls?: object;
    productId?: string;
    providerName?: string;
    requirements?: string;
    rootSourceUrl?: string;
    subtype?: string;
    supportedLanguages?: string[];
    supportedProducts?: ManifestValidationProduct[];
    type?: string;
    version?: string;
}
export declare class ManifestValidationIssue {
    code?: string;
    column?: number;
    line?: number;
    title?: string;
    content?: string;
    helpUrl?: string;
}
export declare class ManifestValidationProduct {
    code?: string;
    title?: string;
    version?: string;
}
export declare class ManifestValidationReport {
    status?: string;
    errors?: ManifestValidationIssue[];
    warnings?: ManifestValidationIssue[];
    notes?: ManifestValidationIssue[];
    addInDetails?: ManifestValidationDetails;
}
export declare class ManifestValidation {
    isValid: boolean;
    report?: ManifestValidationReport;
    status?: number;
    statusText?: string;
    constructor();
}
export declare function validateManifest(manifestPath: string, verifyProduction?: boolean): Promise<ManifestValidation>;
