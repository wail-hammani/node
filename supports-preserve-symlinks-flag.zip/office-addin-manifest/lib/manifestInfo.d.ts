export declare class DefaultSettings {
    sourceLocation?: string;
    requestedWidth?: string;
    requestedHeight?: string;
}
export declare class ManifestInfo {
    id?: string;
    allowSnapshot?: string;
    alternateId?: string;
    appDomains?: string[];
    defaultLocale?: string;
    description?: string;
    displayName?: string;
    highResolutionIconUrl?: string;
    hosts?: string[];
    iconUrl?: string;
    officeAppType?: string;
    permissions?: string;
    providerName?: string;
    supportUrl?: string;
    version?: string;
    defaultSettings?: DefaultSettings;
}
