/**
 * The Office apps which can host Office Add-ins.
 */
export declare enum OfficeApp {
    Excel = "excel",
    OneNote = "onenote",
    Outlook = "outlook",
    PowerPoint = "powerpoint",
    Project = "project",
    Word = "word"
}
/**
 * Get the Office app for the manifest Host name
 * @param host Host name
 */
export declare function getOfficeAppForManifestHost(host: string): OfficeApp | undefined;
/**
 * Gets the Office application name suitable for display.
 * @param app Office app
 */
export declare function getOfficeAppName(app: OfficeApp): string;
/**
 * Gets the Office application names suitable for display.
 * @param apps Office apps
 */
export declare function getOfficeAppNames(apps: OfficeApp[]): string[];
/**
 * Returns the Office apps that support Office add-ins.
 */
export declare function getOfficeApps(): OfficeApp[];
/**
 * Get the Office apps for the manifest Host names.
 * @param hosts Host names specified in the manifest.
 */
export declare function getOfficeAppsForManifestHosts(hosts?: string[]): OfficeApp[];
/**
 * Converts the string to the OfficeApp enum value.
 * @param value string
 * @throws Error if the value is not a valid Office app.
 */
export declare function parseOfficeApp(value: string): OfficeApp;
/**
 * Converts the strings to the OfficeApp enum values.
 * @param input "all" for all Office apps, or a comma-separated list of one or more Office apps.
 * @throws Error if a value is not a valid Office app.
 */
export declare function parseOfficeApps(input: string): OfficeApp[];
/**
 * Returns the OfficeApp enum for the value, or undefined if not valid.
 * @param value Office app string
 */
export declare function toOfficeApp(value: string): OfficeApp | undefined;
