export declare type Xml = any;
/**
 * Given an xml element, returns the value of the attribute with the specified name.
 * @param xml Xml object
 * @param name Attribute name
 * @returns The attribute value or undefined
 * @example Given the the following xml, the attribute name "DefaultValue" will return the value "abc".
 *   <First DefaultValue="abc">1</First>
 */
export declare function getXmlAttributeValue(xml: Xml, name: string): string | undefined;
/**
 * Given an xml object, returns the first inner element with the specified name, or undefined.
 * @param xml Xml object
 * @param name Element name
 * @returns Xml object or undefined
 * @example Given the the following xml, the name "Second" will return the xml object for <Second>...</Second>.
 *   <Current>
 *     <First>1</First>
 *     <Second>2</Second>
 *   </Current>
 */
export declare function getXmlElement(xml: Xml, name: string): Xml | undefined;
/**
 * Given an xml object, returns the attribute value for the first inner element with the specified name, or undefined.
 * @param xml Xml object
 * @param elementName Element name
 * @param attributeName Attribute name
 * @example Given the the following xml, the element name "First" and attribute name "DefaultValue" will return the value "abc".
 *   <Current>
 *     <First DefaultValue="abc">1</First>
 *   </Current>
 */
export declare function getXmlElementAttributeValue(xml: Xml, elementName: string, attributeName?: string): string | undefined;
/**
 * Given an xml object, returns an array with the inner elements with the specified name.
 * @param xml Xml object
 * @param name Element name
 * @returns Array of xml objects;
 * @example Given the the following xml, the name "Item" will return an array with the two items.
 *   <Items>
 *     <Item>1</Item>
 *     <Item>2</Item>
 *   </Items>
 */
export declare function getXmlElements(xml: Xml, name: string): Xml[];
/**
 * Given an xml object, for the specified element, returns the values of the inner elements with the specified item element name.
 * @param xml The xml object.
 * @param name The name of the inner xml element.
 * @example Given the the following xml, the container name "Items" and item name "Item" will return ["One", "Two"].
 * If the attributeName is "AnotherValue", then it will return ["First", "Second"].
 *   <Items>
 *     <Item DefaultValue="One" AnotherValue="First">1</Item>
 *     <Item DefaultValue="Two" AnotherValue="Second">2</Item>
 *   </Current>
 */
export declare function getXmlElementsAttributeValue(xml: Xml, name: string, itemElementName: string, attributeName?: string): string[];
/**
 * Given an xml object, for the specified element, returns the values of the inner elements with the specified item element name.
 * @param xml The xml object.
 * @param name The name of the inner xml element.
 * @example Given the the following xml, the container name "Items" and item name "Item" will return ["1", "2"].
 *   <Items>
 *     <Item>1</Item>
 *     <Item>2</Item>
 *   </Current>
 */
export declare function getXmlElementsValue(xml: Xml, name: string, itemElementName: string): string[];
/**
 * Returns the value of the first inner xml element with the specified name.
 * @param xml The xml object.
 * @param name The name of the inner xml element.
 * @example Given the the following xml, the name "Second" will return the value "2".
 *   <Current>
 *     <First>1</First>
 *     <Second>2</Second>
 *   </Current>
 */
export declare function getXmlElementValue(xml: Xml, name: string): string | undefined;
/**
 * Given an xml object, set the attribute value for the specified element name.
 * @param xml Xml object
 * @param elementName Element name
 * @param attributeValue Attribute value
 * @param attributeName Attribute name
 */
export declare function setXmlElementAttributeValue(xml: Xml, elementName: string, attributeValue: string | undefined, attributeName?: string): void;
/**
 * Given an xml object, set the inner xml element
 * @param xml Xml object
 * @param elementName Element name
 * @param elementValue Element value
 */
export declare function setXmlElementValue(xml: Xml, elementName: string, elementValue: any): void;
