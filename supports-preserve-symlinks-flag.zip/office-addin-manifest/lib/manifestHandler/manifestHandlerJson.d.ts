import { devPreview, TeamsAppManifest } from "@microsoft/teams-manifest";
import { ManifestInfo } from "../manifestInfo";
import { ManifestHandler } from "./manifestHandler";
export declare class ManifestHandlerJson extends ManifestHandler {
    modifyManifest(guid?: string, displayName?: string): Promise<TeamsAppManifest>;
    parseManifest(): Promise<ManifestInfo>;
    getManifestInfo(appManifest: devPreview.DevPreviewSchema): ManifestInfo;
    writeManifestData(manifestData: TeamsAppManifest): Promise<void>;
}
