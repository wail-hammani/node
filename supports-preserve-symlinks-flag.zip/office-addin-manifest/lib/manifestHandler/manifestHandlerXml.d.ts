import * as xmlMethods from "../xml";
import { ManifestInfo } from "../manifestInfo";
import { ManifestHandler } from "./manifestHandler";
export declare type Xml = xmlMethods.Xml;
export declare class ManifestHandlerXml extends ManifestHandler {
    modifyManifest(guid?: string, displayName?: string): Promise<Xml>;
    parseManifest(): Promise<ManifestInfo>;
    parseXmlAsync(): Promise<Xml>;
    readFromManifestFile(): Promise<string>;
    setModifiedXmlData(xml: any, guid: string | undefined, displayName: string | undefined): void;
    writeManifestData(manifestData: any): Promise<void>;
}
