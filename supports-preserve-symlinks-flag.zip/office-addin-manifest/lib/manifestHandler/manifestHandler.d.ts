import { ManifestInfo } from "../manifestInfo";
export declare abstract class ManifestHandler {
    constructor(manifestPath: string);
    abstract modifyManifest(guid?: string, displayName?: string): Promise<any>;
    abstract parseManifest(): Promise<ManifestInfo>;
    abstract writeManifestData(manifestData: any): Promise<void>;
    manifestPath: string;
}
