import { ManifestInfo } from "./manifestInfo";
export declare namespace OfficeAddinManifest {
    function modifyManifestFile(manifestPath: string, guid?: string, displayName?: string): Promise<ManifestInfo>;
    function readManifestFile(manifestPath: string): Promise<ManifestInfo>;
}
