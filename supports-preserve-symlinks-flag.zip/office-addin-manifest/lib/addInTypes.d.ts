/**
 * The types of Office add-ins.
 */
export declare enum AddInType {
    Content = "content",
    Mail = "mail",
    TaskPane = "taskpane"
}
/**
 * Get the Office app for the manifest Host name
 * @param host Host name
 */
export declare function getAddInTypeForManifestOfficeAppType(officeAppType: string): AddInType | undefined;
/**
 * Returns the Office add-in types.
 */
export declare function getAddInTypes(): AddInType[];
/**
 * Converts the string to the AddInType enum value.
 * @param value string
 * @throws Error if the value is not a valid Office add-in type.
 */
export declare function parseAddInType(value: string): AddInType;
/**
 * Converts the strings to the AddInType enum values.
 * @param input "all" for all Office add-in types, or a comma-separated list of one or more Office apps.
 * @throws Error if a value is not a valid Office app.
 */
export declare function parseAddInTypes(input: string): AddInType[];
/**
 * Returns the AddInType enum for the value, or undefined if not valid.
 * @param value Office add-in type string
 */
export declare function toAddInType(value: string): AddInType | undefined;
