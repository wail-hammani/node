#!/usr/bin/env node
export declare function run(host?: string, port?: string, role?: string, debuggerName?: string): void;
