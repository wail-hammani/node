# Office-Addin-Node-Debugger

This package allows a Node instance to serve as a proxy for debugging a JavaScript runtime hosted by an Office application.