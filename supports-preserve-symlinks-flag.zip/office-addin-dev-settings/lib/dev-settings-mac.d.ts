import { OfficeApp } from "office-addin-manifest";
import { RegisteredAddin } from "./dev-settings";
export declare function getRegisteredAddIns(): Promise<RegisteredAddin[]>;
export declare function registerAddIn(manifestPath: string, officeApps?: OfficeApp[], registration?: string): Promise<void>;
export declare function unregisterAddIn(addinId: string, manifestPath: string): Promise<void>;
export declare function unregisterAllAddIns(): Promise<void>;
