/**
 * The type of Office application.
 */
export declare enum AppType {
    /**
     * Office application for Windows or Mac
     */
    Desktop = "desktop",
    /**
     * Office application for the web browser
     */
    Web = "web"
}
/**
 * Parse the input text and get the associated AppType
 * @param text app-type/platform text
 * @returns AppType or undefined.
 */
export declare function parseAppType(text: string | undefined): AppType | undefined;
