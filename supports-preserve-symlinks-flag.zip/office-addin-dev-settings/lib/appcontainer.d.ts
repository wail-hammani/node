export declare const EdgeBrowserAppcontainerName: string;
export declare const EdgeWebViewAppcontainerName: string;
export declare const EdgeBrowserName: string;
export declare const EdgeWebViewName: string;
/**
 * Adds a loopback exemption for the appcontainer.
 * @param name Appcontainer name
 * @throws Error if platform does not support appcontainers.
 */
export declare function addLoopbackExemptionForAppcontainer(name: string): Promise<void>;
/**
 * Returns whether appcontainer is supported on the current platform.
 * @returns True if platform supports using appcontainer; false otherwise.
 */
export declare function isAppcontainerSupported(): boolean;
/**
 * Adds a loopback exemption for the appcontainer.
 * @param name Appcontainer name
 * @throws Error if platform does not support appcontainers.
 */
export declare function isLoopbackExemptionForAppcontainer(name: string): Promise<boolean>;
/**
 * Returns the name of the appcontainer used to run an Office Add-in.
 * @param sourceLocation Source location of the Office Add-in.
 * @param isFromStore True if installed from the Store; false otherwise.
 */
export declare function getAppcontainerName(sourceLocation: string, isFromStore?: boolean): string;
export declare function getUserConfirmation(name: string): Promise<boolean>;
export declare function getAppcontainerNameFromManifestPath(manifestPath: string): Promise<string>;
export declare function getDisplayNameFromManifestPath(manifestPath: string): string;
export declare function ensureLoopbackIsEnabled(manifestPath: string, askForConfirmation?: boolean): Promise<boolean>;
/**
 * Returns the name of the appcontainer used to run an Office Add-in.
 * @param manifestPath Path of the manifest file.
 */
export declare function getAppcontainerNameFromManifest(manifestPath: string): Promise<string>;
/**
 * Removes a loopback exemption for the appcontainer.
 * @param name Appcontainer name
 * @throws Error if platform doesn't support appcontainers.
 */
export declare function removeLoopbackExemptionForAppcontainer(name: string): Promise<void>;
