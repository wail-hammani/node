export type AccountOperation = "login" | "logout";
export declare function registerWithTeams(zipPath: string): Promise<string>;
export declare function updateM365Account(operation: AccountOperation): Promise<void>;
export declare function unacquireWithTeams(titleId: string): Promise<void>;
