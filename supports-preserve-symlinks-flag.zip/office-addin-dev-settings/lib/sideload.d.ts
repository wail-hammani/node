import { AddInType, ManifestInfo, OfficeApp } from "office-addin-manifest";
import { AppType } from "./appType";
/**
 * Create an Office document in the temporary files directory
 * which can be opened to launch the Office app and load the add-in.
 * @param app Office app
 * @param manifest Manifest for the add-in.
 * @returns Path to the file.
 */
export declare function generateSideloadFile(app: OfficeApp, manifest: ManifestInfo, document?: string): Promise<string>;
/**
 * Create an Office document url with query params which can be opened
 * to register an Office add-in in Office Online.
 * @param manifestPath Path to the manifest file for the Office Add-in.
 * @param documentUrl Office Online document url
 * @param isTest Indicates whether to append test query param to suppress Office Online dialogs.
 * @returns Document url with query params appended.
 */
export declare function generateSideloadUrl(manifestFileName: string, manifest: ManifestInfo, documentUrl: string, isTest?: boolean): Promise<string>;
/**
 * Returns the path to the document used as a template for sideloading,
 * or undefined if sideloading is not supported.
 * @param app Specifies the Office app.
 * @param addInType Specifies the type of add-in.
 */
export declare function getTemplatePath(app: OfficeApp, addInType: AddInType): string | undefined;
/**
 * Starts the Office app and loads the Office Add-in.
 * @param manifestPath Path to the manifest file for the Office Add-in.
 * @param app Office app to launch.
 * @param canPrompt
 */
export declare function sideloadAddIn(manifestPath: string, app?: OfficeApp, canPrompt?: boolean, appType?: AppType, document?: string, registration?: string): Promise<void>;
