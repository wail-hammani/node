export { toWebViewTypeName } from "./dev-settings-windows";
export declare enum DebuggingMethod {
    Direct = 0,
    Proxy = 1,
    /** @deprecated use Proxy */
    Web = 1
}
export declare enum WebViewType {
    Default = "Default",
    IE = "IE",
    Edge = "Edge",
    EdgeChromium = "Edge Chromium"
}
export declare class RegisteredAddin {
    id: string;
    manifestPath: string;
    constructor(id: string, manifestPath: string);
}
export declare class SourceBundleUrlComponents {
    host?: string;
    port?: string;
    path?: string;
    extension?: string;
    get url(): string;
    constructor(host?: string, port?: string, path?: string, extension?: string);
}
export declare function clearDevSettings(addinId: string): Promise<void>;
export declare function disableDebugging(addinId: string): Promise<void>;
export declare function disableLiveReload(addinId: string): Promise<void>;
export declare function disableRuntimeLogging(): Promise<void>;
export declare function enableDebugging(addinId: string, enable?: boolean, method?: DebuggingMethod, openDevTools?: boolean): Promise<void>;
export declare function enableLiveReload(addinId: string, enable?: boolean): Promise<void>;
export declare function enableRuntimeLogging(path?: string): Promise<string>;
/**
 * Returns the manifest paths for the add-ins that are registered
 */
export declare function getRegisterAddIns(): Promise<RegisteredAddin[]>;
export declare function getEnabledDebuggingMethods(addinId: string): Promise<DebuggingMethod[]>;
export declare function getOpenDevTools(addinId: string): Promise<boolean>;
export declare function getRuntimeLoggingPath(): Promise<string | undefined>;
export declare function getSourceBundleUrl(addinId: string): Promise<SourceBundleUrlComponents>;
export declare function getWebView(addinId: string): Promise<WebViewType | undefined>;
export declare function isDebuggingEnabled(addinId: string): Promise<boolean>;
export declare function isLiveReloadEnabled(addinId: string): Promise<boolean>;
export declare function registerAddIn(manifestPath: string, registration?: string): Promise<void>;
export declare function setSourceBundleUrl(addinId: string, components: SourceBundleUrlComponents): Promise<void>;
export declare function setWebView(addinId: string, webViewType: WebViewType | undefined): Promise<void>;
export declare function unregisterAddIn(manifestPath: string): Promise<void>;
export declare function unregisterAllAddIns(): Promise<void>;
