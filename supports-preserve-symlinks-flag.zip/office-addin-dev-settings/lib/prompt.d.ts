import { OfficeApp } from "office-addin-manifest";
export declare function chooseOfficeApp(apps: OfficeApp[]): Promise<OfficeApp>;
