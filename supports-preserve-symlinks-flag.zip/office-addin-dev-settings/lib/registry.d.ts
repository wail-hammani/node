import * as winreg from "winreg";
export declare class RegistryKey {
    winreg: winreg.Registry;
    get path(): string;
    constructor(path: string);
}
export declare class RegistryTypes {
    static readonly REG_BINARY: string;
    static readonly REG_DWORD: string;
    static readonly REG_EXPAND_SZ: string;
    static readonly REG_MULTI_SZ: string;
    static readonly REG_NONE: string;
    static readonly REG_QWORD: string;
    static readonly REG_SZ: string;
}
export declare class RegistryValue {
    key: string;
    name: string;
    type: string;
    data: string;
    get isNumberType(): boolean;
    get isStringType(): boolean;
    constructor(key: string, name: string, type: string, data: string);
}
export declare function addBooleanValue(key: RegistryKey, value: string, data: boolean): Promise<void>;
export declare function addNumberValue(key: RegistryKey, value: string, data: number): Promise<void>;
export declare function addStringValue(key: RegistryKey, value: string, data: string): Promise<void>;
export declare function deleteKey(key: RegistryKey): Promise<void>;
export declare function deleteValue(key: RegistryKey, value: string): Promise<void>;
export declare function doesKeyExist(key: RegistryKey): Promise<boolean>;
export declare function doesValueExist(key: RegistryKey, value: string): Promise<boolean>;
export declare function getNumberValue(key: RegistryKey, value: string): Promise<number | undefined>;
export declare function getStringValue(key: RegistryKey, value: string): Promise<string | undefined>;
export declare function getValue(key: RegistryKey, value: string): Promise<RegistryValue | undefined>;
export declare function getValues(key: RegistryKey): Promise<RegistryValue[]>;
export declare function isNumberType(registryType: string): boolean;
export declare function isStringType(registryType: string): boolean;
