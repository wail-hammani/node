/**
 * Logs an error message
 * @param err The error to be logged
 */
export declare function logErrorMessage(err: any): void;
