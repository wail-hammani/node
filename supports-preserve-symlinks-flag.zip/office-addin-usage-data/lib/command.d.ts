export declare function listUsageDataSettings(): void;
export declare function turnUsageDataOff(): void;
export declare function turnUsageDataOn(): void;
