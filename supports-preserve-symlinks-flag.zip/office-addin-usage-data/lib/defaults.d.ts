export declare const usageDataJsonFilePath: string;
export declare const groupName: string;
export declare const instrumentationKeyForOfficeAddinCLITools: string;
export declare const generatorOffice: string;
