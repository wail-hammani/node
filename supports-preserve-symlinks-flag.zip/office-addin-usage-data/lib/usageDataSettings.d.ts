import { UsageDataLevel } from "./usageData";
/**
 * Allows developer to check if the program has already prompted before
 * @param groupName Group name of the usage data object
 * @returns Boolean of whether the program should prompt
 */
export declare function needToPromptForUsageData(groupName: string): boolean;
/**
 * Allows developer to add or modify a specific property to the group
 * @param groupName Group name of property
 * @param property Property that will be created or modified
 * @param value Property's value that will be assigned
 */
export declare function modifyUsageDataJsonData(groupName: string, property: any, value: any): void;
/**
 * Returns the session identifier
 * @returns The uuid of the session identifier
 */
export declare function readDeviceID(): string;
/**
 * Reads data from the usage data json config file
 * @returns Parsed object from json file if it exists
 */
export declare function readUsageDataJsonData(): any;
/**
 * Returns whether usage data is enabled on the usage data object
 * @param groupName Group name to search for in the specified json data
 * @returns Whether usage data is enabled specific to the group name
 */
export declare function readUsageDataLevel(groupName: string): UsageDataLevel;
/**
 * Returns whether usage data is enabled on the usage data object
 * @param groupName Group name to search for in the specified json data
 * @param propertyName Property name that will be used to access and return the associated value
 * @returns Property of the specific group name
 */
export declare function readUsageDataObjectProperty(groupName: string, propertyName: string): any;
/**
 * Writes to usage data config file either appending to already existing file or creating new file
 * @param groupName Group name of usage data object
 * @param level usageDataLevel Whether user is sending none or full usage data
 */
export declare function writeUsageDataJsonData(groupName: string, level: UsageDataLevel): void;
/**
 * Checks to see if the given group name exists in the specified json data
 * @param groupName Group name to search for in the specified json data
 * @returns Boolean of whether group name exists
 */
export declare function groupNameExists(groupName: string): boolean;
/**
 * Reads usage data settings from the usage data json config file for a specific group
 * @returns Settings for the specified group
 */
export declare function readUsageDataSettings(groupName?: string): object | undefined;
