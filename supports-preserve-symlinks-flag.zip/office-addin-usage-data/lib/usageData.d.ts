/**
 * Specifies the usage data infrastructure the user wishes to use
 * @enum Application Insights: Microsoft Azure service used to collect and query through data
 */
export declare enum UsageDataReportingMethod {
    applicationInsights = "applicationInsights"
}
/**
 * Level controlling what type of usage data is being sent
 * @enum off: off level of usage data, sends no usage data
 * @enum on: on level of usage data, sends errors and events
 */
export declare enum UsageDataLevel {
    off = "off",
    on = "on"
}
/**
 * Defines an error that is expected to happen given some situation
 * @member message Message to be logged in the error
 */
export declare class ExpectedError extends Error {
    constructor(message: string | undefined);
}
/**
 * UpdateData options
 * @member groupName Group name for usage data settings (Optional)
 * @member projectName The name of the project that is using the usage data package.
 * @member instrumentationKey Instrumentation key for usage data resource
 * @member promptQuestion Question displayed to user over opt-in for usage data (Optional)
 * @member raisePrompt Specifies whether to raise usage data prompt (this allows for using a custom prompt) (Optional)
 * @member usageDataLevel User's response to the prompt for usage data (Optional)
 * @member method The desired method to use for reporting usage data. (Optional)
 * @member isForTesting True if the data is just for testing, false for actual data that should be reported. (Optional)
 */
export interface IUsageDataOptions {
    groupName?: string;
    projectName: string;
    instrumentationKey: string;
    promptQuestion?: string;
    raisePrompt?: boolean;
    usageDataLevel?: UsageDataLevel;
    method?: UsageDataReportingMethod;
    isForTesting?: boolean;
    deviceID?: string;
}
/**
 * Creates and initializes member variables while prompting user for usage data collection when necessary
 * @param usageDataObject
 */
export declare class OfficeAddinUsageData {
    private usageDataClient;
    private eventsSent;
    private exceptionsSent;
    private options;
    private defaultData;
    constructor(usageDataOptions: IUsageDataOptions);
    /**
     * Reports custom event object to usage data structure
     * @param eventName Event name sent to usage data structure
     * @param data Data object sent to usage data structure
     */
    reportEvent(eventName: string, data: object): Promise<void>;
    /**
     * Reports custom event object to Application Insights
     * @param eventName Event name sent to Application Insights
     * @param data Data object sent to Application Insights
     */
    reportEventApplicationInsights(eventName: string, data: object): Promise<void>;
    /**
     * Reports error to usage data structure
     * @param errorName Error name sent to usage data structure
     * @param err Error sent to usage data structure
     */
    reportError(errorName: string, err: Error): Promise<void>;
    /**
     * Reports error to Application Insights
     * @param errorName Error name sent to Application Insights
     * @param err Error sent to Application Insights
     */
    reportErrorApplicationInsights(errorName: string, err: Error): Promise<void>;
    /**
     * Prompts user for usage data participation once and records response
     * @param testData Specifies whether test code is calling this method
     * @param testReponse Specifies test response
     */
    usageDataOptIn(testData?: boolean, testResponse?: string): void;
    /**
     * Stops usage data from being sent, by default usage data will be on
     */
    setUsageDataOff(): void;
    /**
     * Starts sending usage data, by default usage data will be on
     */
    setUsageDataOn(): void;
    /**
     * Returns whether the usage data is currently on or off
     * @returns Whether usage data is turned on or off
     */
    isUsageDataOn(): boolean;
    /**
     * Returns the instrumentation key associated with the resource
     * @returns The usage data instrumentation key
     */
    getUsageDataKey(): string;
    /**
     * Transform the project name by adddin '-test' suffix to it if necessary
     */
    private getEventName;
    /**
     * Returns the amount of events that have been sent
     * @returns The count of events sent
     */
    getEventsSent(): any;
    /**
     * Returns the amount of exceptions that have been sent
     * @returns The count of exceptions sent
     */
    getExceptionsSent(): any;
    /**
     * Get the usage data level
     * @returns the usage data level
     */
    getUsageDataLevel(): string;
    /**
     * Returns parsed file path, scrubbing file names and sensitive information
     * @returns Error after removing PII
     */
    maskFilePaths(err: Error): Error;
    /**
     * Removes sensitive information fields from ApplicationInsights data
     */
    private removeApplicationInsightsSensitiveInformation;
    /**
     * Reports custom exception event object to Application Insights
     * @param method Method name sent to Application Insights
     * @param err Error or message about error sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     */
    reportException(method: string, err: Error | string, data?: object): void;
    /**
     * Reports custom expected exception event object to Application Insights
     * @param method Method name sent to Application Insights
     * @param err Error or message about error sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     */
    reportExpectedException(method: string, err: Error | string, data?: object): void;
    /**
     * Reports custom success event object to Application Insights
     * @param method Method name sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     */
    reportSuccess(method: string, data?: object): void;
    /**
     * Reports custom exception event object to Application Insights
     * @param method Method name sent to Application Insights
     * @param err Error or message about error sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     * @deprecated Use `reportUnexpectedError` instead.
     */
    sendUsageDataException(method: string, err: Error | string, data?: object): void;
    /**
     * Reports custom success event object to Application Insights
     * @param method Method name sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     * @deprecated Use `reportSuccess` instead.
     */
    sendUsageDataSuccessEvent(method: string, data?: object): void;
    /**
     * Reports custom successful fail event object to Application Insights
     * "Successful fail" means that there was an error as a result of user error, but our code worked properly
     * @param method Method name sent to Application Insights
     * @param data Data object(s) sent to Application Insights
     * @deprecated Use `reportExpectedError` instead.
     */
    sendUsageDataSuccessfulFailEvent(method: string, data?: object): void;
    /**
     * Reports custom event object to Application Insights
     * @param data Data object(s) sent to Application Insights
     */
    sendUsageDataEvent(data?: object): void;
}
