/// <reference types="node" />
import { ChildProcess } from "child_process";
export declare function startProcess(commandLine: string, verbose?: boolean): Promise<void>;
export declare function startDetachedProcess(commandLine: string, verbose?: boolean): ChildProcess;
export declare function stopProcess(processId: number): void;
