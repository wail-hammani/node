export interface IDebuggingInfo {
    devServer: IDevServerInfo;
}
export interface IDevServerInfo {
    processId: number | undefined;
}
export declare function getDebuggingInfoPath(): string;
/**
 * Saves the process id of the dev server
 * @param id process id
 */
export declare function saveDevServerProcessId(id: number): Promise<void>;
/**
 * Read the process id from either the environment variable or
 * from the json file containing the debug info
 */
export declare function readDevServerProcessId(): number | undefined;
/**
 * Deletes the environment variable containing process id
 * and deletes the debug info json file if it exists
 */
export declare function clearDevServerProcessId(): void;
