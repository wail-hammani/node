import * as devSettings from "office-addin-dev-settings";
import { DebuggingMethod } from "office-addin-dev-settings";
import { OfficeApp } from "office-addin-manifest";
export declare enum AppType {
    Desktop = "desktop",
    Web = "web"
}
export declare enum Platform {
    Android = "android",
    Desktop = "desktop",
    iOS = "ios",
    MacOS = "macos",
    Win32 = "win32",
    Web = "web"
}
export declare function isDevServerRunning(port: number): Promise<boolean>;
export declare function isPackagerRunning(statusUrl: string): Promise<boolean>;
export declare function parseDebuggingMethod(text: string): DebuggingMethod | undefined;
export declare function parsePlatform(text: string): Platform | undefined;
export declare function runDevServer(commandLine: string, port?: number): Promise<void>;
export declare function runNodeDebugger(host?: string, port?: string): Promise<void>;
export declare function runPackager(commandLine: string, host?: string, port?: string): Promise<void>;
/**
 * `startDebugging` options.
 */
export interface StartDebuggingOptions {
    /**
     * The type of application to debug.
     */
    appType: AppType;
    /**
     * The Office application to debug.
     * If unspecified and there is more than one application in the manifest will prompt to specify the application.
     */
    app?: OfficeApp;
    /**
     * The method to use when debugging.
     */
    debuggingMethod?: DebuggingMethod;
    /**
     * Specify components of the source bundle url.
     */
    sourceBundleUrlComponents?: devSettings.SourceBundleUrlComponents;
    /**
     * If provided, starts the dev server.
     */
    devServerCommandLine?: string;
    /**
     *  If provided, port to verify that the dev server is running.
     */
    devServerPort?: number;
    /**
     *  If provided, starts the packager.
     */
    packagerCommandLine?: string;
    /**
     * Specifies the host name of the packager.
     */
    packagerHost?: string;
    /**
     * Specifies the port of the packager.
     */
    packagerPort?: string;
    /**
     * Enable debugging.
     * Starts with debugging if true or undefined.
     */
    enableDebugging?: boolean;
    /**
     * Enable live reload.
     */
    enableLiveReload?: boolean;
    /**
     * Enables launch of the Office host app and sideload of the add-in (if true or undefined).
     * Set to false to disable sideload.
     */
    enableSideload?: boolean;
    /**
     * Open Dev Tools.
     */
    openDevTools?: boolean;
    /**
     * If provided, the document to open for sideloading to web.
     */
    document?: string;
}
/**
 * Start debugging
 * @param options startDebugging options.
 */
export declare function startDebugging(manifestPath: string, options: StartDebuggingOptions): Promise<void>;
export declare function waitUntil(callback: () => Promise<boolean>, retryCount: number, retryDelay: number): Promise<boolean>;
export declare function waitUntilDevServerIsRunning(port: number, retryCount?: number, retryDelay?: number): Promise<boolean>;
export declare function waitUntilPackagerIsRunning(statusUrl: string, retryCount?: number, retryDelay?: number): Promise<boolean>;
