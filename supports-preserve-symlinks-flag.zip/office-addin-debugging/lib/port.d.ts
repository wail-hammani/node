/**
 * Determines whether a port is in use.
 * @param port port number (0 - 65535)
 * @returns true if port is in use; false otherwise.
 */
export declare function isPortInUse(port: number): Promise<boolean>;
/**
 * Return the process ids using the port.
 * @param port port number (0 - 65535)
 * @returns Promise to array containing process ids, or empty if none.
 */
export declare function getProcessIdsForPort(port: number): Promise<number[]>;
/**
 * Returns a random port number which is not in use.
 * @returns Promise to number from 0 to 65535
 */
export declare function randomPortNotInUse(): Promise<number>;
