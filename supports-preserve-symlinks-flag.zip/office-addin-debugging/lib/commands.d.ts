import * as commander from "commander";
export declare function start(manifestPath: string, platform: string | undefined, command: commander.Command): Promise<void>;
export declare function stop(manifestPath: string, platform: string | undefined, command: commander.Command): Promise<void>;
