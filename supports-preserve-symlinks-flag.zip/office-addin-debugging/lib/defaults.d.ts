import * as usageData from "office-addin-usage-data";
export declare const usageDataObject: usageData.OfficeAddinUsageData;
