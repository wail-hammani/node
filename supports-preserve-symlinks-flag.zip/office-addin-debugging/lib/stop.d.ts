export declare function stopDebugging(manifestPath: string): Promise<void>;
