/// <reference types="node" />
interface IHttpsServerOptions {
    ca: Buffer;
    cert: Buffer;
    key: Buffer;
}
export declare function getHttpsServerOptions(): Promise<IHttpsServerOptions>;
export {};
