export declare const outputMarker: string;
export declare function isCaCertificateInstalled(returnInvalidCertificate?: boolean): boolean;
export declare function verifyCertificates(certificatePath?: string, keyPath?: string): boolean;
