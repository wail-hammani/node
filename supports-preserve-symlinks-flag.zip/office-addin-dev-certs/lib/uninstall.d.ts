export declare function deleteCertificateFiles(certificateDirectory?: string): void;
export declare function uninstallCaCertificate(machine?: boolean, verbose?: boolean): Promise<void>;
