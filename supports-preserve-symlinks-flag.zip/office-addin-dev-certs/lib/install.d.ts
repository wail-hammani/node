export declare function ensureCertificatesAreInstalled(daysUntilCertificateExpires?: number, domains?: string[], machine?: boolean): Promise<void>;
export declare function installCaCertificate(caCertificatePath?: string, machine?: boolean): Promise<void>;
