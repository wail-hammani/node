
0.1.1 / 2013-12-30 
==================

 * expose parse
 * rename lib to index

0.1.0 / 2013-12-28
==================

  * API BREAKING! `get` has been changed, see the README for migration path
  * Add `set` method
  * Start using simple-assert (closes #2)

0.0.1 / 2013-11-24
==================

  * Initial implementation
