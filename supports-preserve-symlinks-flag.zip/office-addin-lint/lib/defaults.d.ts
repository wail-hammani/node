import * as usageData from "office-addin-usage-data";
export declare const lintFiles = "src/**/*.{ts,tsx,js,jsx}";
export declare enum ESLintExitCode {
    NoLintErrors = 0,
    HasLintError = 1,
    CommandFailed = 2
}
export declare enum PrettierExitCode {
    NoFormattingProblems = 0,
    HasFormattingProblem = 1,
    CommandFailed = 2
}
export declare const usageDataObject: usageData.OfficeAddinUsageData;
