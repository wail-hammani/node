export declare function getLintCheckCommand(files: string, useTestConfig?: boolean): string;
export declare function performLintCheck(files: string, useTestConfig?: boolean): void;
export declare function getLintFixCommand(files: string, useTestConfig?: boolean): string;
export declare function performLintFix(files: string, useTestConfig?: boolean): void;
export declare function getPrettierCommand(files: string): string;
export declare function makeFilesPrettier(files: string): void;
