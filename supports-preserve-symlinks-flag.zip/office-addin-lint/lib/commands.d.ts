import * as commander from "commander";
export declare function lint(command: commander.Command): Promise<void>;
export declare function lintFix(command: commander.Command): Promise<void>;
export declare function prettier(command: commander.Command): Promise<void>;
