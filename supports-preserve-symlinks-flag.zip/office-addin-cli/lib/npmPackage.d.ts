export declare function clearCachedScripts(): void;
/**
 * Gets a script command from package json during a npm execution
 * @param scriptName The name of the script
 */
export declare function getPackageJsonScript(scriptName: string): Promise<string | undefined>;
