/**
 * Logs an error message
 * @param err The error to be logged
 * @deprecated scriptName The name of the script
 */
export declare function logErrorMessage(err: any): void;
