export declare function parseNumber(optionValue: any, errorMessage?: string): number | undefined;
