# Office-Addin-CLI

A command-line interface for Office Add-ins.

