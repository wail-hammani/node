module.exports = {
    printWidth: 160,
    tabWidth: 4,
    singleQuote: true,
    endOfLine: 'lf',
    trailingComma: 'none',
    arrowParens: 'avoid'
};
