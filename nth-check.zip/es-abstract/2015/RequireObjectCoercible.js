'use strict';

module.exports = require('../5/CheckObjectCoercible');
