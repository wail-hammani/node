declare type EncodeTrieNode = string | {
    v?: string;
    n: number | Map<number, EncodeTrieNode>;
    o?: string;
};
declare const _default: Map<number, EncodeTrieNode>;
export default _default;
//# sourceMappingURL=encode-html.d.ts.map