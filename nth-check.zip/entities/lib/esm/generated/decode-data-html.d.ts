declare const _default: Uint16Array;
export default _default;
//# sourceMappingURL=decode-data-html.d.ts.map